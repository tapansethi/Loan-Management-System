<?php
$link = mysqli_connect("localhost","root","","loan") or die("Unable to Connect to Database");
?>

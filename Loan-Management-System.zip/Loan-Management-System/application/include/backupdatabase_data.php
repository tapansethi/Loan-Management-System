<div class="box">
	
	       <div class="box-body">
			<div class="panel panel-success">
            <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-database"></i> Backup Database</h3>
            </div>
             <div class="box-body">
 
              
			<a href="backup.php"class="btn btn-success btn-flat"><i class="fa fa-send"></i>&nbsp;Backup Database</a>
		

	</div>	
	</div>
	</div>	
	</div>